"""Evaluation helpers."""
